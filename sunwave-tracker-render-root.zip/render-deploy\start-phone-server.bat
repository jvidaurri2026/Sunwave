@echo off
setlocal
cd /d "%~dp0"
set "BUNDLED_PY=C:\Users\galvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%BUNDLED_PY%" (
  "%BUNDLED_PY%" server.py --host 0.0.0.0 --port 4178
) else (
  where py >nul 2>nul
  if %errorlevel%==0 (
  py -3 server.py --host 0.0.0.0 --port 4178
  ) else (
  python server.py --host 0.0.0.0 --port 4178
  )
)

from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote
import argparse
import csv
import hashlib
import io
import json
import os
import secrets
import shutil
import sqlite3
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, time as clock_time
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("SUNWAVE_DATA_DIR", ROOT / "data"))
DB_PATH = DATA_DIR / "equiptrack.db"
GROUPME_SETTINGS_PATH = DATA_DIR / "groupme-settings.json"
LOCAL_TZ = ZoneInfo("America/Chicago")
INVENTORY_FINISH_DATE_KEY = "inventory_finish_date"
INVENTORY_AUTO_SENT_DATE_KEY = "inventory_auto_groupme_sent_date"
INVENTORY_AUTO_SEND_HOUR = 21
INVENTORY_AUTO_SEND_MINUTE = 0

DEFAULT_USERS = [
    ("admin", "admin123", "Admin User", "Admin"),
    ("manager", "manager123", "Field Manager", "Manager"),
    ("viewer", "viewer123", "Viewer User", "Viewer"),
]

DEFAULT_EQUIPMENT = [
    ("sample-comm-trailer", "GEN-0012", "EQ-0001", "Comm Trailer", "Available", "", "Yard 3", "29.7604", "-95.3698", "Ready for deployment."),
    ("sample-pump", "TAB-0142", "IT-0142", "Pump", "Available", "", "Main Office", "30.2672", "-97.7431", "Screen replacement scheduled."),
]

DEFAULT_CATEGORIES = [
    "Comm Trailer",
    "Manifold",
    "Half Pipe 12\"",
    "Half Pipe 16\"",
    "Traditional",
    "Pump",
    "Ground Manifold 4x4",
    "Ground Manifold 4x3",
    "Ground Manifold 2x2",
]

DEFAULT_JOBS = []
DEFAULT_QUANTITY_ASSET_CATEGORY = "12\" to 10\" Reducer"
DEFAULT_QUANTITY_ASSET_MASTER_NUMBER = "9000"


def iso_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def local_today():
    return datetime.now(LOCAL_TZ).date().isoformat()


def local_now_label():
    return datetime.now(LOCAL_TZ).strftime("%b %d, %Y %I:%M %p")


def password_hash(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def is_available_assignment(value):
    return not (value or "").strip() or (value or "").strip().lower() == "available"


def is_yard_assignment(value):
    return (value or "").strip().lower() == "yard"


def is_real_job_assignment(value):
    return bool((value or "").strip()) and not is_available_assignment(value) and not is_yard_assignment(value)


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DATA_DIR.mkdir(exist_ok=True)
    bundled_db = ROOT / "data" / "equiptrack.db"
    if not DB_PATH.exists() and bundled_db.exists() and bundled_db.resolve() != DB_PATH.resolve():
        shutil.copy2(bundled_db, DB_PATH)
    with connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
              username TEXT PRIMARY KEY,
              password_hash TEXT NOT NULL,
              name TEXT NOT NULL,
              role TEXT NOT NULL CHECK(role IN ('Admin', 'Manager', 'Viewer'))
            );

            CREATE TABLE IF NOT EXISTS sessions (
              token TEXT PRIMARY KEY,
              username TEXT NOT NULL REFERENCES users(username),
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS app_settings (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS equipment (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              asset_tag TEXT NOT NULL,
              category TEXT NOT NULL,
              status TEXT NOT NULL CHECK(status IN ('Active', 'Available', 'Maintenance', 'Retired')),
              assigned_to TEXT,
              site TEXT,
              latitude TEXT,
              longitude TEXT,
              photos TEXT,
              notes TEXT,
              updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS categories (
              name TEXT PRIMARY KEY,
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS jobs (
              name TEXT PRIMARY KEY,
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS asset_history (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              equipment_id TEXT NOT NULL,
              equipment_name TEXT NOT NULL,
              asset_tag TEXT NOT NULL,
              assigned_to TEXT,
              latitude TEXT,
              longitude TEXT,
              changed_by TEXT,
              changed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS job_audits (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              audit_date TEXT NOT NULL,
              job_name TEXT NOT NULL,
              item_type TEXT NOT NULL,
              asset_number TEXT,
              hose_size TEXT,
              total_hose TEXT,
              latitude TEXT,
              longitude TEXT,
              notes TEXT,
              created_by TEXT,
              created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS saved_job_audits (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              batch_id TEXT NOT NULL,
              status TEXT NOT NULL,
              audit_date TEXT NOT NULL,
              job_name TEXT NOT NULL,
              item_type TEXT NOT NULL,
              asset_number TEXT,
              hose_size TEXT,
              total_hose TEXT,
              latitude TEXT,
              longitude TEXT,
              notes TEXT,
              created_by TEXT,
              created_at TEXT NOT NULL,
              saved_by TEXT,
              saved_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS job_audit_asset_history (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              batch_id TEXT NOT NULL,
              job_name TEXT NOT NULL,
              asset_number TEXT NOT NULL,
              equipment_id TEXT,
              equipment_name TEXT,
              asset_tag TEXT,
              audit_status TEXT NOT NULL,
              released_status TEXT NOT NULL,
              changed_by TEXT,
              changed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS quantity_assets (
              category TEXT PRIMARY KEY,
              master_number TEXT NOT NULL,
              quantity INTEGER NOT NULL DEFAULT 0,
              updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS quantity_asset_history (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              category TEXT NOT NULL,
              master_number TEXT NOT NULL,
              job_name TEXT,
              change_type TEXT NOT NULL CHECK(change_type IN ('Add', 'Use')),
              quantity INTEGER NOT NULL,
              balance_after INTEGER NOT NULL,
              latitude TEXT,
              longitude TEXT,
              changed_by TEXT,
              changed_at TEXT NOT NULL
            );
            """
        )

        equipment_sql = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'equipment'"
        ).fetchone()["sql"]
        if "'Available'" not in equipment_sql:
            conn.executescript(
                """
                CREATE TABLE equipment_new (
                  id TEXT PRIMARY KEY,
                  name TEXT NOT NULL,
                  asset_tag TEXT NOT NULL,
                  category TEXT NOT NULL,
                  status TEXT NOT NULL CHECK(status IN ('Active', 'Available', 'Maintenance', 'Retired')),
                  assigned_to TEXT,
                  site TEXT,
                  latitude TEXT,
                  longitude TEXT,
                  notes TEXT,
                  updated_at TEXT NOT NULL
                );
                INSERT INTO equipment_new (
                  id, name, asset_tag, category, status, assigned_to,
                  site, latitude, longitude, notes, updated_at
                )
                SELECT
                  id, name, asset_tag, category, status, assigned_to,
                  site, latitude, longitude, notes, updated_at
                FROM equipment;
                DROP TABLE equipment;
                ALTER TABLE equipment_new RENAME TO equipment;
                """
            )

        existing_equipment_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(equipment)").fetchall()
        }
        if "photos" not in existing_equipment_columns:
            conn.execute("ALTER TABLE equipment ADD COLUMN photos TEXT")

        existing_job_audit_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(job_audits)").fetchall()
        }
        if "hose_size" not in existing_job_audit_columns:
            conn.execute("ALTER TABLE job_audits ADD COLUMN hose_size TEXT")
        if "total_hose" not in existing_job_audit_columns:
            conn.execute("ALTER TABLE job_audits ADD COLUMN total_hose TEXT")

        existing_saved_job_audit_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(saved_job_audits)").fetchall()
        }
        if "total_hose" not in existing_saved_job_audit_columns:
            conn.execute("ALTER TABLE saved_job_audits ADD COLUMN total_hose TEXT")

        existing_quantity_history_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(quantity_asset_history)").fetchall()
        }
        if "latitude" not in existing_quantity_history_columns:
            conn.execute("ALTER TABLE quantity_asset_history ADD COLUMN latitude TEXT")
        if "longitude" not in existing_quantity_history_columns:
            conn.execute("ALTER TABLE quantity_asset_history ADD COLUMN longitude TEXT")

        for username, password, name, role in DEFAULT_USERS:
            conn.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, name, role) VALUES (?, ?, ?, ?)",
                (username, password_hash(password), name, role),
            )

        for category in DEFAULT_CATEGORIES:
            conn.execute(
                "INSERT OR IGNORE INTO categories (name, created_at) VALUES (?, ?)",
                (category, iso_now()),
            )

        conn.execute(
            "INSERT OR IGNORE INTO categories (name, created_at) VALUES (?, ?)",
            (DEFAULT_QUANTITY_ASSET_CATEGORY, iso_now()),
        )
        for job in DEFAULT_JOBS:
            conn.execute(
                "INSERT OR IGNORE INTO jobs (name, created_at) VALUES (?, ?)",
                (job, iso_now()),
            )

        count = conn.execute("SELECT COUNT(*) AS count FROM equipment").fetchone()["count"]
        if count == 0:
            now = iso_now()
            for item in DEFAULT_EQUIPMENT:
                conn.execute(
                    """
                    INSERT INTO equipment (
                      id, name, asset_tag, category, status, assigned_to,
                      site, latitude, longitude, notes, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (*item, now),
                )

        history_count = conn.execute("SELECT COUNT(*) AS count FROM asset_history").fetchone()["count"]
        if history_count == 0:
            now = iso_now()
            rows = conn.execute(
                """
                SELECT id, name, asset_tag, assigned_to, latitude, longitude
                FROM equipment
                WHERE COALESCE(assigned_to, '') <> ''
                   OR COALESCE(latitude, '') <> ''
                   OR COALESCE(longitude, '') <> ''
                """
            ).fetchall()
            for row in rows:
                conn.execute(
                    """
                    INSERT INTO asset_history (
                      equipment_id, equipment_name, asset_tag, assigned_to,
                      latitude, longitude, changed_by, changed_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        row["id"],
                        row["name"],
                        row["asset_tag"],
                        row["assigned_to"] or "",
                        row["latitude"] or "",
                        row["longitude"] or "",
                        "system",
                        now,
                    ),
                )


def equipment_from_row(row):
    try:
        photos = json.loads(row["photos"] or "[]")
    except (TypeError, json.JSONDecodeError):
        photos = []
    assigned_to = row["assigned_to"] or ""
    return {
        "id": row["id"],
        "name": row["name"],
        "assetTag": row["asset_tag"],
        "category": row["category"],
        "status": "Available" if is_available_assignment(assigned_to) else "Active",
        "assignedTo": assigned_to,
        "latitude": row["latitude"] or "",
        "longitude": row["longitude"] or "",
        "photos": photos if isinstance(photos, list) else [],
        "notes": row["notes"] or "",
        "updatedAt": row["updated_at"],
    }


def history_from_row(row):
    return {
        "id": row["id"],
        "equipmentId": row["equipment_id"],
        "equipmentName": row["equipment_name"],
        "assetTag": row["asset_tag"],
        "assignedTo": row["assigned_to"] or "",
        "latitude": row["latitude"] or "",
        "longitude": row["longitude"] or "",
        "changedBy": row["changed_by"] or "",
        "changedAt": row["changed_at"],
    }


def job_audit_from_row(row):
    return {
        "id": row["id"],
        "auditDate": row["audit_date"],
        "jobName": row["job_name"],
        "itemType": row["item_type"],
        "assetNumber": row["asset_number"] or "",
        "hoseSize": row["hose_size"] or "",
        "totalHose": row["total_hose"] or "",
        "latitude": row["latitude"] or "",
        "longitude": row["longitude"] or "",
        "notes": row["notes"] or "",
        "createdBy": row["created_by"] or "",
        "createdAt": row["created_at"],
    }


def saved_job_audit_from_row(row):
    item = job_audit_from_row(row)
    item.update(
        {
            "batchId": row["batch_id"],
            "status": row["status"],
            "savedBy": row["saved_by"] or "",
            "savedAt": row["saved_at"],
        }
    )
    return item


def saved_job_audit_summary_from_row(row):
    return {
        "batchId": row["batch_id"],
        "status": row["status"],
        "auditDate": row["audit_date"],
        "jobName": row["job_name"],
        "itemCount": row["item_count"],
        "savedBy": row["saved_by"] or "",
        "savedAt": row["saved_at"],
    }


def quantity_asset_from_row(row):
    categories = row["categories"] if "categories" in row.keys() else row["category"]
    category_list = [category.strip() for category in str(categories or "").split("||") if category.strip()]
    return {
        "category": ", ".join(category_list),
        "categories": category_list,
        "masterNumber": row["master_number"],
        "quantity": row["quantity"],
        "updatedAt": row["updated_at"],
    }


def quantity_asset_history_from_row(row):
    return {
        "id": row["id"],
        "category": row["category"],
        "masterNumber": row["master_number"],
        "jobName": row["job_name"] or "",
        "changeType": row["change_type"],
        "quantity": row["quantity"],
        "balanceAfter": row["balance_after"],
        "latitude": row["latitude"] or "",
        "longitude": row["longitude"] or "",
        "changedBy": row["changed_by"] or "",
        "changedAt": row["changed_at"],
    }


def load_groupme_settings():
    settings = {}
    bundled_path = ROOT / "data" / "groupme-settings.json"
    for path in (bundled_path, GROUPME_SETTINGS_PATH):
        if path.exists():
            with path.open("r", encoding="utf-8") as handle:
                settings.update(json.load(handle))
    env_bot_id = os.environ.get("GROUPME_BOT_ID", "").strip()
    if env_bot_id:
        settings["botId"] = env_bot_id
    return settings


def post_groupme_message(text):
    settings = load_groupme_settings()
    bot_id = (settings.get("botId") or "").strip()
    if not bot_id:
        raise RuntimeError("GroupMe bot is not configured.")

    payload = json.dumps({"bot_id": bot_id, "text": text}).encode("utf-8")
    request = urllib.request.Request(
        "https://api.groupme.com/v3/bots/post",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            if response.status not in (200, 201, 202):
                raise RuntimeError(f"GroupMe returned status {response.status}.")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(detail or f"GroupMe returned status {exc.code}.") from exc
    except Exception as exc:
        post_groupme_message_with_curl(payload, exc)


def post_groupme_message_with_curl(payload, original_error):
    curl_path = Path("C:/Windows/System32/curl.exe")
    if not curl_path.exists():
        raise RuntimeError(str(original_error) or "Could not connect to GroupMe.") from original_error

    result = subprocess.run(
        [
            str(curl_path),
            "-sS",
            "-X",
            "POST",
            "-H",
            "Content-Type: application/json",
            "--data-binary",
            "@-",
            "https://api.groupme.com/v3/bots/post",
        ],
        input=payload,
        capture_output=True,
        timeout=30,
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).decode("utf-8", errors="replace").strip()
        raise RuntimeError(detail or str(original_error) or "Could not send GroupMe message.") from original_error


def groupme_keyword_response(message):
    text = str(message.get("text") or "").strip().lower()
    if not text:
        return None
    if str(message.get("sender_type") or "").strip().lower() == "bot":
        return None

    settings = load_groupme_settings()
    for item in settings.get("keywordResponses") or []:
        keyword = str(item.get("keyword") or "").strip().lower()
        response = str(item.get("response") or "").strip()
        action = str(item.get("action") or "").strip()
        if keyword and keyword in text:
            return {"response": response, "action": action}
    return None


def get_app_setting(conn, key):
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else ""


def set_app_setting(conn, key, value):
    conn.execute(
        """
        INSERT INTO app_settings (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
          value = excluded.value,
          updated_at = excluded.updated_at
        """,
        (key, value, iso_now()),
    )


def mark_inventory_finished():
    with connect() as conn:
        set_app_setting(conn, INVENTORY_FINISH_DATE_KEY, local_today())


def yard_snapshot_text_from_db(title="Sunwave Tracker Yard Snapshot"):
    with connect() as conn:
        equipment = conn.execute(
            """
            SELECT COALESCE(NULLIF(TRIM(category), ''), 'Uncategorized') AS category, COUNT(*) AS count
            FROM equipment
            WHERE LOWER(TRIM(COALESCE(assigned_to, ''))) = 'yard'
            GROUP BY COALESCE(NULLIF(TRIM(category), ''), 'Uncategorized')
            ORDER BY category
            """
        ).fetchall()
        quantities = conn.execute(
            """
            SELECT master_number, category, SUM(quantity) AS quantity
            FROM quantity_asset_history
            WHERE change_type = 'Use'
              AND LOWER(TRIM(COALESCE(job_name, ''))) = 'yard'
            GROUP BY master_number, category
            HAVING quantity > 0
            ORDER BY master_number, category
            """
        ).fetchall()

    total_assets = sum(row["count"] for row in equipment)
    total_quantity = sum(row["quantity"] for row in quantities)
    lines = [
        title,
        local_now_label(),
        f"Assets on Yard: {total_assets}",
        f"Master quantity on Yard: {total_quantity}",
        "",
        "Equipment:",
    ]
    lines.extend([f"{row['category']}: {row['count']}" for row in equipment] or ["None"])
    lines.extend(["", "Master quantities:"])
    lines.extend(
        [f"Master #{row['master_number']} - {row['category']}: {row['quantity']}" for row in quantities]
        or ["None"]
    )
    return "\n".join(lines)


def should_send_inventory_auto_snapshot():
    today = local_today()
    now = datetime.now(LOCAL_TZ)
    if now.time() < clock_time(INVENTORY_AUTO_SEND_HOUR, INVENTORY_AUTO_SEND_MINUTE):
        return False

    with connect() as conn:
        finished_date = get_app_setting(conn, INVENTORY_FINISH_DATE_KEY)
        auto_sent_date = get_app_setting(conn, INVENTORY_AUTO_SENT_DATE_KEY)
    return finished_date != today and auto_sent_date != today


def send_inventory_auto_snapshot_if_needed():
    if not should_send_inventory_auto_snapshot():
        return

    message = yard_snapshot_text_from_db("Sunwave Tracker Yard Snapshot AUTO")
    post_groupme_message(message)
    with connect() as conn:
        set_app_setting(conn, INVENTORY_AUTO_SENT_DATE_KEY, local_today())


def inventory_auto_snapshot_loop():
    while True:
        try:
            send_inventory_auto_snapshot_if_needed()
        except Exception as exc:
            print(f"Automatic GroupMe Yard snapshot failed: {exc}")
        time.sleep(60)


def start_inventory_auto_snapshot_scheduler():
    thread = threading.Thread(target=inventory_auto_snapshot_loop, daemon=True)
    thread.start()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_GET(self):
        if self.path == "/api/equipment":
            return self.list_equipment()
        if self.path == "/api/equipment.csv":
            return self.export_equipment()
        if self.path == "/api/asset-history":
            return self.list_asset_history()
        if self.path == "/api/job-audits":
            return self.list_job_audits()
        if self.path == "/api/current-audits":
            return self.list_current_audits()
        if self.path == "/api/audit-history":
            return self.list_audit_history()
        if self.path.startswith("/api/current-audits/"):
            batch_id = unquote(self.path.split("/api/current-audits/", 1)[1])
            return self.list_current_audit_detail(batch_id)
        if self.path == "/api/users":
            return self.list_users()
        if self.path == "/api/categories":
            return self.list_categories()
        if self.path == "/api/jobs":
            return self.list_jobs()
        if self.path == "/api/quantity-assets":
            return self.list_quantity_assets()
        if self.path == "/api/quantity-asset-history":
            return self.list_quantity_asset_history()
        return super().do_GET()

    def do_POST(self):
        if self.path == "/api/login":
            return self.login()
        if self.path == "/api/groupme/callback":
            return self.groupme_callback()
        if self.path == "/api/logout":
            return self.logout()
        if self.path == "/api/equipment":
            return self.save_equipment()
        if self.path == "/api/users":
            return self.save_user()
        if self.path == "/api/categories":
            return self.save_category()
        if self.path == "/api/jobs":
            return self.save_job()
        if self.path == "/api/quantity-assets":
            return self.save_quantity_asset()
        if self.path == "/api/quantity-assets/adjust":
            return self.adjust_quantity_asset()
        if self.path == "/api/job-audits":
            return self.save_job_audit()
        if self.path == "/api/job-audits/save-list":
            return self.save_job_audit_list()
        if self.path == "/api/groupme/yard-inventory":
            return self.send_yard_inventory_groupme()
        if self.path.startswith("/api/current-audits/") and self.path.endswith("/status"):
            batch_id = unquote(self.path.split("/api/current-audits/", 1)[1].rsplit("/status", 1)[0])
            return self.update_current_audit_status(batch_id)
        return self.send_json({"error": "Not found."}, 404)

    def do_DELETE(self):
        if self.path.startswith("/api/equipment/"):
            equipment_id = unquote(self.path.split("/api/equipment/", 1)[1])
            return self.delete_equipment(equipment_id)
        if self.path.startswith("/api/categories/"):
            name = unquote(self.path.split("/api/categories/", 1)[1])
            return self.delete_category(name)
        if self.path.startswith("/api/jobs/"):
            name = unquote(self.path.split("/api/jobs/", 1)[1])
            return self.delete_job(name)
        if self.path.startswith("/api/quantity-assets/"):
            master_number = unquote(self.path.split("/api/quantity-assets/", 1)[1])
            return self.delete_quantity_asset(master_number)
        return self.send_json({"error": "Not found."}, 404)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(raw or "{}")

    def send_json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def current_user(self):
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return None
        token = auth.split(" ", 1)[1].strip()
        with connect() as conn:
            return conn.execute(
                """
                SELECT users.username, users.name, users.role
                FROM sessions
                JOIN users ON users.username = sessions.username
                WHERE sessions.token = ?
                """,
                (token,),
            ).fetchone()

    def require_user(self):
        user = self.current_user()
        if user is None:
            self.send_json({"error": "Session expired. Please sign in again."}, 401)
        return user

    def require_admin(self):
        user = self.require_user()
        if user is None:
            return None
        if user["role"] != "Admin":
            self.send_json({"error": "Only admins can manage users."}, 403)
            return None
        return user

    def login(self):
        data = self.read_json()
        username = (data.get("username") or "").strip()
        password = data.get("password") or ""
        with connect() as conn:
            user = conn.execute(
                "SELECT username, name, role FROM users WHERE username = ? AND password_hash = ?",
                (username, password_hash(password)),
            ).fetchone()
            if user is None:
                return self.send_json({"error": "Username or password is incorrect."}, 401)

            token = secrets.token_urlsafe(32)
            conn.execute(
                "INSERT INTO sessions (token, username, created_at) VALUES (?, ?, ?)",
                (token, username, iso_now()),
            )

        self.send_json({"token": token, "user": dict(user)})

    def logout(self):
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth.split(" ", 1)[1].strip()
            with connect() as conn:
                conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        self.send_json({"ok": True})

    def groupme_callback(self):
        data = self.read_json()
        match = groupme_keyword_response(data)
        if match:
            try:
                response = match["response"]
                if match["action"] == "yard_snapshot":
                    response = yard_snapshot_text_from_db("Sunwave Tracker Yard Snapshot")
                post_groupme_message(response)
            except Exception as exc:
                print(f"GroupMe keyword response failed: {exc}")
        self.send_json({"ok": True})

    def send_yard_inventory_groupme(self):
        if self.require_user() is None:
            return

        data = self.read_json()
        text = (data.get("text") or "").strip()
        if not text:
            return self.send_json({"error": "GroupMe message is empty."}, 400)

        mark_inventory_finished()

        try:
            post_groupme_message(text)
        except Exception as exc:
            return self.send_json({"error": str(exc) or "Could not send GroupMe message."}, 500)

        self.send_json({"ok": True})

    def list_equipment(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute("SELECT * FROM equipment ORDER BY updated_at DESC, name ASC").fetchall()
        self.send_json([equipment_from_row(row) for row in rows])

    def list_asset_history(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM asset_history
                ORDER BY changed_at DESC, id DESC
                LIMIT 500
                """
            ).fetchall()
        self.send_json([history_from_row(row) for row in rows])

    def list_job_audits(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM job_audits
                ORDER BY created_at DESC, id DESC
                LIMIT 500
                """
            ).fetchall()
        self.send_json([job_audit_from_row(row) for row in rows])

    def list_current_audits(self):
        if self.require_user() is None:
            return
        self.send_json(self.saved_audit_summaries(exclude_status="Job Done"))

    def list_audit_history(self):
        if self.require_user() is None:
            return
        self.send_json(self.saved_audit_summaries("Job Done"))

    def saved_audit_summaries(self, status=None, exclude_status=None):
        where_parts = []
        params = []
        if status:
            where_parts.append("status = ?")
            params.append(status)
        if exclude_status:
            where_parts.append("status <> ?")
            params.append(exclude_status)
        where = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""
        with connect() as conn:
            rows = conn.execute(
                f"""
                SELECT
                  batch_id,
                  status,
                  MIN(audit_date) AS audit_date,
                  GROUP_CONCAT(DISTINCT job_name) AS job_name,
                  COUNT(*) AS item_count,
                  saved_by,
                  saved_at
                FROM saved_job_audits
                {where}
                GROUP BY batch_id, status, saved_by, saved_at
                ORDER BY saved_at DESC
                LIMIT 500
                """,
                tuple(params),
            ).fetchall()
        return [saved_job_audit_summary_from_row(row) for row in rows]

    def list_current_audit_detail(self, batch_id):
        if self.require_user() is None:
            return
        if not batch_id:
            return self.send_json({"error": "Audit id is required."}, 400)
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM saved_job_audits
                WHERE batch_id = ?
                ORDER BY id ASC
                """,
                (batch_id,),
            ).fetchall()
        self.send_json([saved_job_audit_from_row(row) for row in rows])

    def list_users(self):
        if self.require_admin() is None:
            return
        with connect() as conn:
            rows = conn.execute("SELECT username, name, role FROM users ORDER BY username ASC").fetchall()
        self.send_json([dict(row) for row in rows])

    def list_categories(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute("SELECT name FROM categories ORDER BY name ASC").fetchall()
        self.send_json([dict(row) for row in rows])

    def list_jobs(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute("SELECT name FROM jobs ORDER BY name ASC").fetchall()
        self.send_json([dict(row) for row in rows])

    def list_quantity_assets(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT
                  master_number,
                  GROUP_CONCAT(category, '||') AS categories,
                  MAX(quantity) AS quantity,
                  MAX(updated_at) AS updated_at
                FROM quantity_assets
                GROUP BY master_number
                ORDER BY master_number ASC
                """
            ).fetchall()
        self.send_json([quantity_asset_from_row(row) for row in rows])

    def list_quantity_asset_history(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM quantity_asset_history
                ORDER BY changed_at DESC, id DESC
                LIMIT 200
                """
            ).fetchall()
        self.send_json([quantity_asset_history_from_row(row) for row in rows])

    def save_quantity_asset(self):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to save quantity assets."}, 403)

        data = self.read_json()
        categories = data.get("categories")
        if not isinstance(categories, list):
            categories = [data.get("category")]
        categories = sorted({str(category or "").strip() for category in categories if str(category or "").strip()})
        master_number = (data.get("masterNumber") or "").strip()
        if not categories or not master_number:
            return self.send_json({"error": "Select at least one category and add a master number."}, 400)

        now = iso_now()
        with connect() as conn:
            existing = conn.execute(
                "SELECT MAX(quantity) AS quantity FROM quantity_assets WHERE master_number = ?",
                (master_number,),
            ).fetchone()
            current_quantity = int(existing["quantity"] or 0) if existing else 0
            for category in categories:
                conn.execute(
                    "INSERT OR IGNORE INTO categories (name, created_at) VALUES (?, ?)",
                    (category, now),
                )
                conn.execute(
                    """
                    INSERT INTO quantity_assets (category, master_number, quantity, updated_at)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(category) DO UPDATE SET
                      master_number = excluded.master_number,
                      quantity = excluded.quantity,
                      updated_at = excluded.updated_at
                    """,
                    (category, master_number, current_quantity, now),
                )
        self.send_json({"ok": True})

    def adjust_quantity_asset(self):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to change quantity assets."}, 403)

        data = self.read_json()
        master_number = (data.get("masterNumber") or "").strip()
        category = (data.get("category") or "").strip()
        action = (data.get("action") or "").strip()
        job_name = (data.get("jobName") or "").strip()
        try:
            quantity = int(data.get("quantity") or 0)
        except (TypeError, ValueError):
            quantity = 0

        if not master_number and not category:
            return self.send_json({"error": "Select a master number."}, 400)
        if action not in ("Add", "Use"):
            return self.send_json({"error": "Select Add or Use."}, 400)
        if quantity <= 0:
            return self.send_json({"error": "Quantity must be greater than zero."}, 400)
        if action == "Use" and not job_name:
            return self.send_json({"error": "Select the job where this quantity was used."}, 400)
        if action == "Use" and not is_real_job_assignment(job_name):
            return self.send_json({"error": "Reduce quantity must be assigned to a job."}, 400)

        with connect() as conn:
            try:
                if action == "Add":
                    next_quantity = self.add_quantity_asset(conn, master_number or category, quantity, user["username"])
                    if is_yard_assignment(job_name):
                        next_quantity = self.use_quantity_asset(conn, master_number or category, quantity, "Yard", user["username"])
                else:
                    next_quantity = self.use_quantity_asset(conn, master_number or category, quantity, job_name, user["username"])
            except ValueError as error:
                return self.send_json({"error": str(error)}, 400)

        self.send_json({"ok": True, "quantity": next_quantity})

    def quantity_asset_rows(self, conn, master_number):
        rows = conn.execute(
            "SELECT * FROM quantity_assets WHERE master_number = ? ORDER BY category ASC",
            (master_number,),
        ).fetchall()
        if rows:
            return master_number, rows
        row = conn.execute(
            "SELECT master_number FROM quantity_assets WHERE category = ?",
            (master_number,),
        ).fetchone()
        if row:
            master_number = row["master_number"]
            rows = conn.execute(
                "SELECT * FROM quantity_assets WHERE master_number = ? ORDER BY category ASC",
                (master_number,),
            ).fetchall()
        return master_number, rows

    def add_quantity_asset(self, conn, master_number, quantity, username):
        master_number, rows = self.quantity_asset_rows(conn, master_number)
        if not rows:
            raise ValueError("This master number is not enabled for quantity tracking yet.")
        now = iso_now()
        current_quantity = int(max(row["quantity"] or 0 for row in rows))
        next_quantity = current_quantity + quantity
        conn.execute(
            "UPDATE quantity_assets SET quantity = ?, updated_at = ? WHERE master_number = ?",
            (next_quantity, now, master_number),
        )
        category_summary = ", ".join(row["category"] for row in rows)
        conn.execute(
            """
            INSERT INTO quantity_asset_history (
              category, master_number, job_name, change_type, quantity,
              balance_after, changed_by, changed_at
            )
            VALUES (?, ?, ?, 'Add', ?, ?, ?, ?)
            """,
            (category_summary, master_number, "", quantity, next_quantity, username, now),
        )
        return next_quantity

    def use_quantity_asset(self, conn, master_number, quantity, job_name, username, latitude="", longitude=""):
        master_number, rows = self.quantity_asset_rows(conn, master_number)
        if not rows:
            raise ValueError("This master number is not enabled for quantity tracking yet.")
        current_quantity = int(max(row["quantity"] or 0 for row in rows))
        assigned_available = self.quantity_asset_assignment_quantity(conn, master_number, "available")
        assigned_yard = self.quantity_asset_assignment_quantity(conn, master_number, "yard")
        usable_quantity = current_quantity + assigned_available + assigned_yard if is_real_job_assignment(job_name) else current_quantity
        if quantity > usable_quantity:
            raise ValueError("Not enough quantity available for this use.")
        now = iso_now()
        next_quantity = max(current_quantity - quantity, 0)
        conn.execute(
            "UPDATE quantity_assets SET quantity = ?, updated_at = ? WHERE master_number = ?",
            (next_quantity, now, master_number),
        )
        category_summary = ", ".join(row["category"] for row in rows)
        if is_real_job_assignment(job_name) and quantity > current_quantity:
            remaining_transfer = quantity - current_quantity
            yard_transfer = min(assigned_yard, remaining_transfer)
            if yard_transfer > 0:
                self.record_quantity_assignment_transfer(
                    conn, category_summary, master_number, "Yard", yard_transfer, next_quantity, username, now
                )
                remaining_transfer -= yard_transfer
            available_transfer = min(assigned_available, remaining_transfer)
            if available_transfer > 0:
                self.record_quantity_assignment_transfer(
                    conn, category_summary, master_number, "Available", available_transfer, next_quantity, username, now
                )
        conn.execute(
            """
            INSERT INTO quantity_asset_history (
              category, master_number, job_name, change_type, quantity,
              balance_after, latitude, longitude, changed_by, changed_at
            )
            VALUES (?, ?, ?, 'Use', ?, ?, ?, ?, ?, ?)
            """,
            (category_summary, master_number, job_name, quantity, next_quantity, latitude, longitude, username, now),
        )
        return next_quantity

    def quantity_asset_assignment_quantity(self, conn, master_number, assignment):
        if assignment == "yard":
            rows = conn.execute(
                """
                SELECT quantity FROM quantity_asset_history
                WHERE master_number = ? AND change_type = 'Use' AND LOWER(TRIM(COALESCE(job_name, ''))) = 'yard'
                """,
                (master_number,),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT quantity FROM quantity_asset_history
                WHERE master_number = ? AND change_type = 'Use'
                  AND (TRIM(COALESCE(job_name, '')) = '' OR LOWER(TRIM(COALESCE(job_name, ''))) = 'available')
                """,
                (master_number,),
            ).fetchall()
        return sum(int(row["quantity"] or 0) for row in rows)

    def record_quantity_assignment_transfer(self, conn, category, master_number, job_name, quantity, balance_after, username, changed_at):
        conn.execute(
            """
            INSERT INTO quantity_asset_history (
              category, master_number, job_name, change_type, quantity,
              balance_after, changed_by, changed_at
            )
            VALUES (?, ?, ?, 'Use', ?, ?, ?, ?)
            """,
            (category, master_number, job_name, -quantity, balance_after, username, changed_at),
        )

    def delete_quantity_asset(self, master_number):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to delete quantity assets."}, 403)

        master_number = (master_number or "").strip()
        if not master_number:
            return self.send_json({"error": "Master number is required."}, 400)

        with connect() as conn:
            rows = conn.execute(
                "SELECT category FROM quantity_assets WHERE master_number = ?",
                (master_number,),
            ).fetchall()
            if not rows:
                return self.send_json({"error": "This master number was not found."}, 404)
            conn.execute("DELETE FROM quantity_assets WHERE master_number = ?", (master_number,))
        self.send_json({"ok": True})

    def save_job(self):
        if self.require_admin() is None:
            return
        data = self.read_json()
        name = (data.get("name") or "").strip()
        if not name:
            return self.send_json({"error": "Job name is required."}, 400)
        with connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO jobs (name, created_at) VALUES (?, ?)",
                (name, iso_now()),
            )
        self.send_json({"ok": True})

    def save_job_audit(self):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to save job audits."}, 403)

        data = self.read_json()
        audit_date = (data.get("auditDate") or "").strip()
        job_name = (data.get("jobName") or "").strip()
        item_type = (data.get("itemType") or "").strip()
        asset_number = (data.get("assetNumber") or "").strip()
        master_number = (data.get("masterNumber") or "").strip()
        try:
            master_quantity = int(data.get("masterQuantity") or 0)
        except (TypeError, ValueError):
            master_quantity = 0
        hose_size = (data.get("hoseSize") or "").strip()
        total_hose = (data.get("totalHose") or "").strip()
        latitude = (data.get("latitude") or "").strip()
        longitude = (data.get("longitude") or "").strip()
        notes = (data.get("notes") or "").strip()

        if master_number or master_quantity:
            item_type = "Master Quantity"
        if item_type not in ("Asset", "Crossing", "Pump", "Pig Around", "Master Quantity"):
            return self.send_json({"error": "Select a valid audit type."}, 400)
        if not audit_date or not job_name:
            return self.send_json({"error": "Date and job are required."}, 400)
        if item_type == "Asset" and not asset_number:
            return self.send_json({"error": "Asset number is required for asset audit entries."}, 400)
        if item_type == "Master Quantity":
            if not master_number or master_quantity <= 0:
                return self.send_json({"error": "Select a master number and enter the quantity used."}, 400)
            asset_number = f"Master #{master_number} x {master_quantity}"
        hose_values = [value.strip() for value in hose_size.split(",") if value.strip()]
        if any(value not in ("16", "12", "10") for value in hose_values):
            return self.send_json({"error": "Select a valid hose size."}, 400)
        if hose_values and not total_hose:
            return self.send_json({"error": "Total hose is required when hose size is selected."}, 400)
        total_hose_by_size = {}
        for part in [value.strip() for value in total_hose.split(",") if value.strip()]:
            if ":" in part:
                size, amount = part.split(":", 1)
                total_hose_by_size[size.strip()] = amount.strip()
        if len(hose_values) > 1 and any(not total_hose_by_size.get(value) for value in hose_values):
            return self.send_json({"error": "Add a total hose value for every selected hose size."}, 400)
        if not latitude or not longitude:
            return self.send_json({"error": "Geolocation is required."}, 400)

        now = iso_now()
        with connect() as conn:
            if item_type == "Asset":
                registered_asset = conn.execute(
                    """
                    SELECT id
                    FROM equipment
                    WHERE id = ? OR name = ? OR asset_tag = ?
                    """,
                    (asset_number, asset_number, asset_number),
                ).fetchone()
                if not registered_asset:
                    return self.send_json({"error": "This asset is not registered yet. Register it before adding it to a job audit."}, 400)
            if item_type == "Master Quantity":
                try:
                    self.use_quantity_asset(conn, master_number, master_quantity, job_name, user["username"], latitude, longitude)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)

            conn.execute(
                """
                INSERT INTO job_audits (
                  audit_date, job_name, item_type, asset_number,
                  hose_size, total_hose, latitude, longitude, notes, created_by, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    audit_date,
                    job_name,
                    item_type,
                    asset_number,
                    hose_size,
                    total_hose,
                    latitude,
                    longitude,
                    notes,
                    user["username"],
                    now,
                ),
            )
        self.send_json({"ok": True})

    def save_job_audit_list(self):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to save job audit lists."}, 403)

        batch_id = str(uuid.uuid4())
        status = "Running"
        saved_at = iso_now()
        with connect() as conn:
            count = conn.execute("SELECT COUNT(*) AS count FROM job_audits").fetchone()["count"]
            if not count:
                return self.send_json({"error": "There are no audit entries to save."}, 400)
            conn.execute(
                """
                INSERT INTO saved_job_audits (
                  batch_id, status, audit_date, job_name, item_type, asset_number,
                  hose_size, total_hose, latitude, longitude, notes, created_by, created_at,
                  saved_by, saved_at
                )
                SELECT
                  ?, ?, audit_date, job_name, item_type, asset_number,
                  hose_size, total_hose, latitude, longitude, notes, created_by, created_at,
                  ?, ?
                FROM job_audits
                ORDER BY id ASC
                """,
                (batch_id, status, user["username"], saved_at),
            )
            conn.execute("DELETE FROM job_audits")
        self.send_json({"ok": True, "count": count, "batchId": batch_id, "status": status, "savedBy": user["username"]})

    def update_current_audit_status(self, batch_id):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to update current audits."}, 403)

        data = self.read_json()
        status = (data.get("status") or "").strip()
        if status not in ("Running", "Rigging Down", "Job Done"):
            return self.send_json({"error": "Select a valid status."}, 400)
        if not batch_id:
            return self.send_json({"error": "Audit id is required."}, 400)

        with connect() as conn:
            cursor = conn.execute(
                "UPDATE saved_job_audits SET status = ? WHERE batch_id = ?",
                (status, batch_id),
            )
            if cursor.rowcount == 0:
                return self.send_json({"error": "Saved audit was not found."}, 404)
            released_count = self.release_current_audit_assets(conn, batch_id, status, user["username"])
        self.send_json({"ok": True, "batchId": batch_id, "status": status, "releasedCount": released_count})

    def release_current_audit_assets(self, conn, batch_id, audit_status, username):
        if audit_status not in ("Rigging Down", "Job Done"):
            return 0

        now = iso_now()
        released_count = 0
        rows = conn.execute(
            """
            SELECT DISTINCT job_name, asset_number
            FROM saved_job_audits
            WHERE batch_id = ?
              AND item_type = 'Asset'
              AND COALESCE(asset_number, '') <> ''
            """,
            (batch_id,),
        ).fetchall()

        for row in rows:
            asset_number = row["asset_number"]
            equipment = conn.execute(
                """
                SELECT id, name, asset_tag
                FROM equipment
                WHERE id = ? OR name = ? OR asset_tag = ?
                LIMIT 1
                """,
                (asset_number, asset_number, asset_number),
            ).fetchone()

            equipment_id = equipment["id"] if equipment else ""
            equipment_name = equipment["name"] if equipment else asset_number
            asset_tag = equipment["asset_tag"] if equipment else ""

            duplicate = conn.execute(
                """
                SELECT id FROM job_audit_asset_history
                WHERE batch_id = ?
                  AND asset_number = ?
                  AND audit_status = ?
                LIMIT 1
                """,
                (batch_id, asset_number, audit_status),
            ).fetchone()
            if duplicate:
                continue

            if equipment:
                conn.execute(
                    """
                    UPDATE equipment
                    SET status = 'Available',
                        updated_at = ?
                    WHERE id = ?
                    """,
                    (now, equipment_id),
                )
                conn.execute(
                    """
                    INSERT INTO asset_history (
                      equipment_id, equipment_name, asset_tag, assigned_to,
                      latitude, longitude, changed_by, changed_at
                    )
                    SELECT id, name, asset_tag, assigned_to, latitude, longitude, ?, ?
                    FROM equipment
                    WHERE id = ?
                    """,
                    (username, now, equipment_id),
                )
                released_count += 1

            conn.execute(
                """
                INSERT INTO job_audit_asset_history (
                  batch_id, job_name, asset_number, equipment_id, equipment_name,
                  asset_tag, audit_status, released_status, changed_by, changed_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Available', ?, ?)
                """,
                (
                    batch_id,
                    row["job_name"],
                    asset_number,
                    equipment_id,
                    equipment_name,
                    asset_tag,
                    audit_status,
                    username,
                    now,
                ),
            )

        return released_count

    def delete_job(self, name):
        if self.require_admin() is None:
            return
        with connect() as conn:
            in_use = conn.execute("SELECT COUNT(*) AS count FROM equipment WHERE assigned_to = ?", (name,)).fetchone()["count"]
            if in_use:
                return self.send_json({"error": "This job value is used by equipment and cannot be deleted."}, 409)
            conn.execute("DELETE FROM jobs WHERE name = ?", (name,))
        self.send_json({"ok": True})

    def save_category(self):
        if self.require_admin() is None:
            return
        data = self.read_json()
        name = (data.get("name") or "").strip()
        if not name:
            return self.send_json({"error": "Category name is required."}, 400)
        with connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO categories (name, created_at) VALUES (?, ?)",
                (name, iso_now()),
            )
        self.send_json({"ok": True})

    def delete_category(self, name):
        if self.require_admin() is None:
            return
        with connect() as conn:
            in_use = conn.execute("SELECT COUNT(*) AS count FROM equipment WHERE category = ?", (name,)).fetchone()["count"]
            if in_use:
                return self.send_json({"error": "This category is used by equipment and cannot be deleted."}, 409)
            conn.execute("DELETE FROM categories WHERE name = ?", (name,))
        self.send_json({"ok": True})

    def save_user(self):
        if self.require_admin() is None:
            return

        data = self.read_json()
        username = (data.get("username") or "").strip()
        original_username = (data.get("originalUsername") or "").strip()
        name = (data.get("name") or "").strip()
        role = (data.get("role") or "").strip()
        password = data.get("password") or ""

        if not username or not name or role not in ("Admin", "Manager", "Viewer"):
            return self.send_json({"error": "Username, name, and role are required."}, 400)

        with connect() as conn:
            existing = conn.execute("SELECT username FROM users WHERE username = ?", (username,)).fetchone()
            if original_username:
                if username != original_username:
                    return self.send_json({"error": "Usernames cannot be changed."}, 400)
                if password:
                    conn.execute(
                        "UPDATE users SET name = ?, role = ?, password_hash = ? WHERE username = ?",
                        (name, role, password_hash(password), username),
                    )
                else:
                    conn.execute(
                        "UPDATE users SET name = ?, role = ? WHERE username = ?",
                        (name, role, username),
                    )
            else:
                if existing is not None:
                    return self.send_json({"error": "That username already exists."}, 409)
                if not password:
                    return self.send_json({"error": "Password is required for a new user."}, 400)
                conn.execute(
                    "INSERT INTO users (username, password_hash, name, role) VALUES (?, ?, ?, ?)",
                    (username, password_hash(password), name, role),
                )

        self.send_json({"ok": True})

    def save_equipment(self):
        user = self.require_user()
        if user is None:
            return
        if user["role"] not in ("Admin", "Manager"):
            return self.send_json({"error": "You do not have permission to save equipment."}, 403)

        data = self.read_json()
        master_number = data.get("masterNumber", "").strip()
        try:
            master_quantity = int(data.get("masterQuantity") or 0)
        except (TypeError, ValueError):
            master_quantity = 0
        has_equipment_fields = any((data.get(field) or "").strip() for field in ("name", "assetTag", "category"))

        if master_number or master_quantity:
            assigned_to = data.get("assignedTo", "").strip()
            if not master_number or master_quantity <= 0:
                return self.send_json({"error": "Select a master number and enter the quantity used."}, 400)
            if is_available_assignment(assigned_to):
                return self.send_json({"error": "Select an Assigned to Job before using a master quantity."}, 400)
            if not has_equipment_fields:
                latitude = data.get("latitude", "").strip()
                longitude = data.get("longitude", "").strip()
                with connect() as conn:
                    try:
                        self.use_quantity_asset(conn, master_number, master_quantity, assigned_to, user["username"], latitude, longitude)
                    except ValueError as error:
                        return self.send_json({"error": str(error)}, 400)
                return self.send_json({"ok": True})

        if not all((data.get(field) or "").strip() for field in ("id", "name")):
            return self.send_json({"error": "Equipment number is required."}, 400)

        with connect() as conn:
            existing = conn.execute("SELECT * FROM equipment WHERE id = ?", (data.get("id"),)).fetchone()
            now = iso_now()
            equipment_id = data.get("id")
            equipment_name = data.get("name", "").strip()
            asset_tag = data.get("assetTag", "").strip()
            if asset_tag:
                duplicate_tag = conn.execute(
                    "SELECT id, name FROM equipment WHERE asset_tag = ? AND id <> ?",
                    (asset_tag, equipment_id),
                ).fetchone()
                if duplicate_tag:
                    return self.send_json({"error": f"That QR code is already assigned to {duplicate_tag['name'] or duplicate_tag['id']}."}, 400)
            assigned_to = data.get("assignedTo", "").strip()
            status = "Available" if is_available_assignment(assigned_to) else "Active"
            latitude = data.get("latitude", "").strip()
            longitude = data.get("longitude", "").strip()
            photos = data.get("photos") if isinstance(data.get("photos"), list) else []
            cleaned_photos = []
            for photo in photos[:6]:
                if not isinstance(photo, dict):
                    continue
                data_url = str(photo.get("dataUrl") or "")
                if not data_url.startswith("data:image/"):
                    continue
                cleaned_photos.append({
                    "name": str(photo.get("name") or "")[:160],
                    "type": str(photo.get("type") or "")[:80],
                    "dataUrl": data_url,
                })
            photos_json = json.dumps(cleaned_photos)
            if master_number and master_quantity:
                try:
                    self.use_quantity_asset(conn, master_number, master_quantity, assigned_to, user["username"], latitude, longitude)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            conn.execute(
                """
                INSERT INTO equipment (
                  id, name, asset_tag, category, status, assigned_to,
                  site, latitude, longitude, photos, notes, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                  name = excluded.name,
                  asset_tag = excluded.asset_tag,
                  category = excluded.category,
                  status = excluded.status,
                  assigned_to = excluded.assigned_to,
                  site = excluded.site,
                  latitude = excluded.latitude,
                  longitude = excluded.longitude,
                  photos = excluded.photos,
                  notes = excluded.notes,
                  updated_at = excluded.updated_at
                """,
                (
                    equipment_id,
                    equipment_name,
                    asset_tag,
                    data.get("category", "").strip() or "Uncategorized",
                    status,
                    assigned_to,
                    "",
                    latitude,
                    longitude,
                    photos_json,
                    data.get("notes", "").strip(),
                    now,
                ),
            )
            if self.should_record_history(existing, assigned_to, latitude, longitude):
                conn.execute(
                    """
                    INSERT INTO asset_history (
                      equipment_id, equipment_name, asset_tag, assigned_to,
                      latitude, longitude, changed_by, changed_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        equipment_id,
                        equipment_name,
                        asset_tag,
                        assigned_to,
                        latitude,
                        longitude,
                        user["username"],
                        now,
                    ),
                )
        self.send_json({"ok": True})

    def should_record_history(self, existing, assigned_to, latitude, longitude):
        if existing is None:
            return bool(assigned_to or latitude or longitude)
        return any(
            [
                (existing["assigned_to"] or "") != assigned_to,
                (existing["latitude"] or "") != latitude,
                (existing["longitude"] or "") != longitude,
            ]
        )

    def delete_equipment(self, equipment_id):
        user = self.require_user()
        if user is None:
            return
        if user["role"] != "Admin":
            return self.send_json({"error": "Only admins can delete equipment."}, 403)
        with connect() as conn:
            conn.execute("DELETE FROM equipment WHERE id = ?", (equipment_id,))
        self.send_json({"ok": True})

    def export_equipment(self):
        if self.require_user() is None:
            return
        with connect() as conn:
            rows = conn.execute("SELECT * FROM equipment ORDER BY updated_at DESC, name ASC").fetchall()

        stream = io.StringIO()
        writer = csv.writer(stream)
        writer.writerow(["Equipment Number", "Asset Tag", "Category", "Status", "Assigned to Job", "Latitude", "Longitude", "Notes", "Updated At"])
        for row in rows:
            item = equipment_from_row(row)
            writer.writerow([item["name"], item["assetTag"], item["category"], item["status"], item["assignedTo"], item["latitude"], item["longitude"], item["notes"], item["updatedAt"]])
        body = stream.getvalue().encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", "attachment; filename=equipment-register.csv")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    parser = argparse.ArgumentParser(description="Run the Sunwave Tracker SQLite server.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "4176")))
    args = parser.parse_args()

    init_db()
    start_inventory_auto_snapshot_scheduler()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Sunwave Tracker database app running at http://{args.host}:{args.port}/")
    print(f"SQLite database file: {DB_PATH}")
    server.serve_forever()


if __name__ == "__main__":
    main()

@echo off
setlocal
cd /d "%~dp0"

where cloudflared >nul 2>nul
if %errorlevel% neq 0 (
  echo Cloudflared is not installed on this computer.
  echo.
  echo Install Cloudflare Tunnel, then run this file again.
  echo This will create an HTTPS public link to Sunwave Tracker.
  echo.
  pause
  exit /b 1
)

echo Starting public HTTPS tunnel for Sunwave Tracker...
echo Keep this window open while using the outside-network link.
echo.
cloudflared tunnel --url http://127.0.0.1:4178
